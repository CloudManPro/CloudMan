import boto3
import json
import os
import logging

# Configuração do Logger para melhor depuração no CloudWatch
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Inicialização dos clientes da AWS fora do handler para reutilização
# O SDK usará automaticamente a IAM Role da Lambda para se autenticar
autoscaling_client = boto3.client('autoscaling')
servicediscovery_client = boto3.client('servicediscovery')


def lambda_handler(event, context):
    """
    Handler principal da função Lambda.
    Acionado por uma notificação SNS de um Auto Scaling Lifecycle Hook.
    """
    logger.info(f"Evento recebido: {json.dumps(event)}")

    # 1. Obter o SERVICE_ID do Cloud Map a partir das variáveis de ambiente da Lambda
    #    É uma boa prática configurar isso como uma variável de ambiente na sua função.
    service_id = os.environ.get('CLOUD_MAP_SERVICE_ID')
    if not service_id:
        logger.error(
            "Erro: A variável de ambiente 'CLOUD_MAP_SERVICE_ID' não está definida.")
        # É crucial não prosseguir se a configuração estiver faltando
        return {'statusCode': 500, 'body': 'Configuração incompleta.'}

    try:
        # 2. Extrair a mensagem do SNS
        #    O evento do SNS contém um campo 'Message' que é uma string JSON.
        message = json.loads(event['Records'][0]['Sns']['Message'])
        logger.info(
            f"Mensagem do Auto Scaling extraída: {json.dumps(message)}")

        # 3. Extrair os detalhes do Lifecycle Hook da mensagem
        lifecycle_hook_name = message['LifecycleHookName']
        auto_scaling_group_name = message['AutoScalingGroupName']
        lifecycle_action_token = message['LifecycleActionToken']
        instance_id = message['EC2InstanceId']
        lifecycle_transition = message['LifecycleTransition']

        # Verificação de segurança para garantir que estamos lidando com um evento de terminação
        if "autoscaling:EC2_INSTANCE_TERMINATING" not in lifecycle_transition:
            logger.warning(
                f"Hook não é de terminação ({lifecycle_transition}). Ignorando.")
            # Informa ao Auto Scaling para continuar, pois não é nossa responsabilidade
            complete_lifecycle_action(
                lifecycle_hook_name, auto_scaling_group_name, lifecycle_action_token, instance_id, 'CONTINUE')
            return {'statusCode': 200, 'body': 'Hook não é de terminação, ignorado.'}

        logger.info(
            f"Iniciando desregistro da instância {instance_id} do serviço {service_id}...")

        # 4. Desregistrar a instância do AWS Cloud Map
        #    O 'instance_id' no Cloud Map deve ser o mesmo 'instance-id' da EC2.
        servicediscovery_client.deregister_instance(
            ServiceId=service_id,
            InstanceId=instance_id
        )
        logger.info(
            f"Sucesso: Instância {instance_id} desregistrada do Cloud Map.")

        # 5. Sinalizar ao Auto Scaling que a ação foi concluída com sucesso
        complete_lifecycle_action(lifecycle_hook_name, auto_scaling_group_name,
                                  lifecycle_action_token, instance_id, 'CONTINUE')
        logger.info(
            f"Sucesso: Ação do ciclo de vida completada para a instância {instance_id}.")

        return {
            'statusCode': 200,
            'body': json.dumps(f'Instância {instance_id} desregistrada e ciclo de vida completado com sucesso.')
        }

    except Exception as e:
        logger.error(f"Ocorreu um erro: {str(e)}")
        # Em caso de falha, é importante tentar sinalizar ao Auto Scaling para abandonar a ação,
        # para que a instância não fique presa no estado de espera para sempre.
        # A mensagem do erro pode não estar disponível se a falha ocorreu antes da sua extração.
        try:
            complete_lifecycle_action(
                lifecycle_hook_name, auto_scaling_group_name, lifecycle_action_token, instance_id, 'ABANDON')
            logger.warning(
                f"Ação do ciclo de vida abandonada para a instância {instance_id} devido a um erro.")
        except NameError:
            logger.error(
                "Não foi possível sinalizar 'ABANDON' ao Auto Scaling pois os detalhes do hook não foram extraídos.")

        # Levanta a exceção para que a Lambda registre a execução como falha.
        raise e


def complete_lifecycle_action(hook_name, group_name, token, instance_id, result):
    """
    Função auxiliar para notificar o Auto Scaling Group sobre o resultado da ação do ciclo de vida.
    """
    try:
        autoscaling_client.complete_lifecycle_action(
            LifecycleHookName=hook_name,
            AutoScalingGroupName=group_name,
            LifecycleActionToken=token,
            LifecycleActionResult=result,  # 'CONTINUE' ou 'ABANDON'
            InstanceId=instance_id
        )
    except Exception as e:
        logger.error(
            f"Erro ao completar a ação do ciclo de vida para a instância {instance_id}: {str(e)}")
        # Mesmo que isso falhe, o log é importante para depuração.
        raise e
