import json

def lambda_handler(event, context):
    """
    Função do manipulador AWS Lambda que retorna uma saudação.
    """
    # O corpo da resposta que você quer enviar
    message = {'message': 'Hello, World!'}

    # Retorna uma resposta formatada para o API Gateway
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json'
        },
        'body': json.dumps(message)
    }