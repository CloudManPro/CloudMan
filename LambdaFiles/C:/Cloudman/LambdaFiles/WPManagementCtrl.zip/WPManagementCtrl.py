<!DOCTYPE html >
<html lang = "pt-BR" >
<head >
    <meta charset = "UTF-8" >
    <meta name = "viewport" content = "width=device-width, initial-scale=1.0" >
    <title > Gerenciador de Instâncias WP < /title >
    <style >
        body {
            font-family: sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 50px;
            background-color:  # f4f4f4;
            margin: 0;
            min-height: 100vh;
        }

        .container {
            background-color:  # fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 90 % ;
            max-width: 500px;
            text-align: center;
        }

        h1 {
            color:  # 333;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color:  # 555;
            font-weight: bold;
            text-align: left;
        }

        select, button {
            width: 100 % ;
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid  # ddd;
            box-sizing: border-box; / * Para padding não aumentar o width * /
            font-size: 16px;
        }

        select {
            cursor: pointer;
        }

        button {
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        # startButton {
            background-color:  # 28a745; /* Verde */
        }
        # startButton:hover {
            background-color:  # 218838;
        }
        # startButton:disabled {
            background-color:  # 94d3a2;
            cursor: not -allowed;
        }

        # stopButton {
            background-color:  # dc3545; /* Vermelho */
        }
        # stopButton:hover {
            background-color:  # c82333;
        }
        # stopButton:disabled {
            background-color:  # eba0a7;
            cursor: not -allowed;
        }

        .button-group {
            display: flex;
            gap: 10px; / * Espaço entre os botões * /
        }

        .button-group button {
            flex: 1; / * Faz os botões ocuparem espaço igual * /
            margin-bottom: 0; / * Remove margem inferior individual se estiverem no grupo * /
        }

        # statusMessage {
            margin-top: 20px;
            padding: 10px;
            border-radius: 5px;
            font-weight: bold;
            min-height: 20px; / * Para não "pular" quando vazio * /
        }

        .status-success {
            background-color:  # d4edda;
            color:  # 155724;
            border: 1px solid  # c3e6cb;
        }

        .status-error {
            background-color:  # f8d7da;
            color:  # 721c24;
            border: 1px solid  # f5c6cb;
        }
        .loading-indicator {
            display: none; / * Escondido por padrão * /
            margin: 10px 0;
            color:  # 007bff;
        }
    < /style >
< / head >
< body >
    < div class = "container" >
        < h1 > Gerenciador de Instâncias < /h1 >

        < label for = "instanceSelector" > Selecione uma Instância: < /label >
        < select id = "instanceSelector" disabled >
            < option value = "" > Carregando instâncias... < /option >
        < / select >

        < div class = "button-group" >
            < button id = "startButton" disabled > Start < /button >
            < button id = "stopButton" disabled > Stop < /button >
        < / div >

        < div class = "loading-indicator" id = "loadingIndicator" > Processando... < /div >
        < div id = "statusMessage" > </div >
    < / div >

    < script >
        const apiUrl = 'https://management.projeto.cloudman.pro/api/WPManagementCtrl'; // SUA API URL
        const instanceSelector = document.getElementById('instanceSelector');
        const startButton = document.getElementById('startButton');
        const stopButton = document.getElementById('stopButton');
        const statusMessageDiv = document.getElementById('statusMessage');
        const loadingIndicator = document.getElementById('loadingIndicator');

        // Função para mostrar/esconder o indicador de loading e desabilitar botões
        function setLoadingState(isLoading) {
            if (isLoading) {
                loadingIndicator.style.display = 'block';
                startButton.disabled = true;
                stopButton.disabled = true;
                instanceSelector.disabled = true;
            } else {
                loadingIndicator.style.display = 'none';
                // Re-habilita baseado se há instâncias selecionáveis
                const hasInstances = instanceSelector.options.length > 0 & & instanceSelector.value != = "";
                startButton.disabled = !hasInstances;
                stopButton.disabled = !hasInstances;
                instanceSelector.disabled = !(instanceSelector.options.length > 0 & & instanceSelector.options[0].value != = ""); // Habilita se não for a msg de "nenhuma instancia"
            }
        }

        // Função para mostrar mensagens de status
        function showStatusMessage(message, isError=false) {
            statusMessageDiv.textContent = message;
            statusMessageDiv.className = isError ? 'status-error': 'status-success'; // Remove classes antigas
            if (message) {
                statusMessageDiv.style.display = 'block';
            } else {
                statusMessageDiv.style.display = 'none';
            }
        }

        // Função para popular o dropdown
        function populateInstanceDropdown(instanceNames) {
            instanceSelector.innerHTML = ''; // Limpa opções existentes

            if (instanceNames & & instanceNames.length > 0) {
                instanceNames.forEach(name= > {
                    const option = document.createElement('option');
                    option.value = name;
                    option.textContent = name;
                    instanceSelector.appendChild(option);
                });
                instanceSelector.disabled = false;
                startButton.disabled = false;
                stopButton.disabled = false;
                showStatusMessage(
                    'Instâncias carregadas. Selecione uma.', false);
            } else {
                const option = document.createElement('option');
                option.value = "";
                option.textContent = "Nenhuma instância encontrada.";
                instanceSelector.appendChild(option);
                instanceSelector.disabled = true;
                startButton.disabled = true;
                stopButton.disabled = true;
                showStatusMessage(
                    'Nenhuma instância alvo foi configurada ou encontrada.', true);
            }
        }

        // Função para buscar os nomes das instâncias na inicialização
        async function fetchInstanceNames() {
            showStatusMessage('Carregando nomes das instâncias...');
            setLoadingState(true);
            try {
                const response = await fetch(apiUrl, {
                    method: 'POST', // A Lambda espera a action no body
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({action: 'read_names'})
                });

                if (!response.ok) {
                    let errorMsg = `Erro HTTP: ${response.status}`;
                    try {
                        const errorData = await response.json();
                        errorMsg = errorData.error | | errorData.message | | errorMsg;
                    } catch (e) { / * Ignora erro de parsing do corpo do erro * / }
                    throw new Error(errorMsg);
                }

                const data = await response.json();
                // Ajuste 'data.target_instance_names' conforme a resposta da sua Lambda
                if (data.target_instance_names) {
                    populateInstanceDropdown(data.target_instance_names);
                } else if (data.found_target_instance_names) { // Tentativa com a chave do código Python anterior
                     populateInstanceDropdown(
                         data.found_target_instance_names);
                }
                else {
                    console.error(
                        'Resposta da API não contém "target_instance_names":', data);
                    populateInstanceDropdown([]); // Trata como lista vazia
                    showStatusMessage(
                        'Formato de resposta inesperado da API ao buscar nomes.', true);
                }

            } catch(error) {
                console.error('Erro ao buscar nomes das instâncias:', error);
                populateInstanceDropdown([]); // Limpa e desabilita
                showStatusMessage(`Erro ao carregar instâncias: ${error.message}`, true);
            } finally {
                setLoadingState(false);
                 // Garante que botões fiquem desabilitados se o dropdown estiver vazio ou com "nenhuma instancia"
                if (instanceSelector.options.length == = 0 | | !instanceSelector.value) {
                    startButton.disabled = true;
                    stopButton.disabled = true;
                }
            }
        }

        // Função para lidar com ações de Start/Stop
        async function handleInstanceAction(actionType) {
            const selectedInstanceName = instanceSelector.value;

            if (!selectedInstanceName) {
                showStatusMessage(
                    'Por favor, selecione uma instância primeiro.', true);
                return;
            }

            showStatusMessage(`Processando ${actionType} para ${selectedInstanceName}...`);
            setLoadingState(true);

            try {
                const response = await fetch(apiUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        action: actionType,
                        name: selectedInstanceName
                    })
                });

                const data = await response.json(); // Tenta parsear mesmo em erro para pegar a msg

                if (!response.ok) {
                   const errorMsg = data.error | | data.message | | `Erro HTTP: ${response.status}`;
                   throw new Error(errorMsg);
                }

                showStatusMessage(data.message | | `${actionType} executado com sucesso para ${selectedInstanceName}.`, false);

            } catch(error) {
                console.error(`Erro ao ${actionType} instância: `, error);
                showStatusMessage(`Erro: ${error.message}`, true);
            } finally {
                setLoadingState(false);
            }
        }

        // Adiciona event listeners
        startButton.addEventListener('click', ()= > handleInstanceAction('start'));
        stopButton.addEventListener('click', ()= > handleInstanceAction('stop'));

        // Carrega os nomes das instâncias quando a página é carregada
        document.addEventListener('DOMContentLoaded', fetchInstanceNames);
    < /script >
< / body >
< / html >
