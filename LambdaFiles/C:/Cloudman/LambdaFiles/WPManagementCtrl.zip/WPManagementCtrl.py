import boto3
import json
import os
import time

# --- Global Scope: Initialization Code ---
ec2_client = boto3.client('ec2')
ssm_client = boto3.client('ssm') # Initialize SSM client

FOUND_TARGET_INSTANCE_NAMES = []
print("Lambda Global: Starting initialization of instance name list from environment variables...")
ENV_VAR_BASE_NAME = "AWS_INSTANCE_TARGET_NAME_"
for i in range(10):
    env_var_key = f"{ENV_VAR_BASE_NAME}{i}"
    instance_name_from_env = os.environ.get(env_var_key)
    if instance_name_from_env:
        print(f"Lambda Global: Found environment variable '{env_var_key}' with value: '{instance_name_from_env}'")
        FOUND_TARGET_INSTANCE_NAMES.append(instance_name_from_env)
    else:
        print(f"Lambda Global: Environment variable '{env_var_key}' not set or is empty. Skipping.")
print(f"Lambda Global: Initialization complete. Collected target instance names: {FOUND_TARGET_INSTANCE_NAMES}")
# --- End of Global Scope Initialization ---

def find_instance_id_by_tag_name(name_tag_value):
    print(f"Function find_instance_id_by_tag_name: Searching for instance with tag Name='{name_tag_value}'")
    try:
        response = ec2_client.describe_instances(
            Filters=[
                {'Name': 'tag:Name', 'Values': [name_tag_value]},
                {'Name': 'instance-state-name', 'Values': ['running']}
            ]
        )
        instances_found_ids = []
        for reservation in response.get('Reservations', []):
            for instance in reservation.get('Instances', []):
                instances_found_ids.append(instance['InstanceId'])
        if not instances_found_ids:
            print(f"Function find_instance_id_by_tag_name: No instance found with tag Name='{name_tag_value}'")
            return None
        if len(instances_found_ids) > 1:
            print(f"Function find_instance_id_by_tag_name: Warning - Multiple instances ({len(instances_found_ids)}) found with tag Name='{name_tag_value}'. Using the first one: {instances_found_ids[0]}")
        print(f"Function find_instance_id_by_tag_name: Instance found: {instances_found_ids[0]}")
        return instances_found_ids[0]
    except Exception as e:
        print(f"Function find_instance_id_by_tag_name: Error describing instances: {str(e)}")
        raise

def get_instance_public_ip(instance_id):
    try:
        print(f"Function get_instance_public_ip: Describing instance {instance_id} to get Public IP.")
        response = ec2_client.describe_instances(InstanceIds=[instance_id])
        if not response.get('Reservations') or not response['Reservations'][0].get('Instances'):
            print(f"Function get_instance_public_ip: Instance {instance_id} not found in describe_instances response.")
            return None
        instance_details = response['Reservations'][0]['Instances'][0]
        public_ip = instance_details.get('PublicIpAddress')
        if public_ip:
            print(f"Function get_instance_public_ip: Instance {instance_id} has Public IP: {public_ip}")
        else:
            print(f"Function get_instance_public_ip: Instance {instance_id} does not have a Public IP assigned.")
        return public_ip
    except Exception as e:
        print(f"Function get_instance_public_ip: Error describing instance {instance_id} to get IP: {str(e)}")
        return None

def execute_ssm_command_and_wait(instance_id, commands_to_run, instance_name_tag_value):
    """
    Executes a shell script via SSM Run Command and waits for completion.
    Returns True if successful, False otherwise.
    """
    print(f"SSM Handler: Attempting to run command on {instance_id} (Name: {instance_name_tag_value})")
    try:
        response = ssm_client.send_command(
            InstanceIds=[instance_id],
            DocumentName='AWS-RunShellScript',
            Parameters={'commands': commands_to_run},
            TimeoutSeconds=300,  # Timeout for the command itself
            Comment=f'Switch WordPress config for {instance_name_tag_value}'
        )
        command_id = response['Command']['CommandId']
        print(f"SSM Handler: Command sent. Command ID: {command_id}. Waiting for completion...")

        # Wait for the command to complete
        # Increased MaxAttempts and Delay for SSM command execution
        for _ in range(20): # Max attempts (e.g., 20 * 10s = 200s total wait for SSM command)
            time.sleep(10) # Poll every 10 seconds
            try:
                result = ssm_client.get_command_invocation(
                    CommandId=command_id,
                    InstanceId=instance_id
                )
                status = result['Status']
                print(f"SSM Handler: Command {command_id} on {instance_id} status: {status}")

                if status == 'Success':
                    print(f"SSM Handler: Command {command_id} on {instance_id} (Name: {instance_name_tag_value}) completed successfully.")
                    print(f"SSM Handler: Standard Output:\n{result.get('StandardOutputContent', 'N/A')}")
                    return True
                elif status in ['Failed', 'Cancelled', 'TimedOut', 'DeliveryTimedOut', 'ExecutionTimedOut']:
                    print(f"SSM Handler: Command {command_id} on {instance_id} (Name: {instance_name_tag_value}) ended with status: {status}")
                    print(f"SSM Handler: Standard Output:\n{result.get('StandardOutputContent', 'N/A')}")
                    print(f"SSM Handler: Standard Error:\n{result.get('StandardErrorContent', 'N/A')}")
                    return False
                # else: InProgress, Pending, etc. - continue loop
            except Exception as poll_e:
                print(f"SSM Handler: Error polling command status for {command_id} on {instance_id}: {str(poll_e)}")
                # Depending on the error, you might want to retry or fail
                return False # Fail on polling error for simplicity here
        
        print(f"SSM Handler: Command {command_id} on {instance_id} (Name: {instance_name_tag_value}) did not complete in the expected time (Lambda polling).")
        return False

    except Exception as e:
        print(f"SSM Handler: Error sending command to instance {instance_id} (Name: {instance_name_tag_value}): {str(e)}")
        return False


def lambda_handler(event, context):
    print(f"Lambda Handler: Event received: {json.dumps(event)}")
    action = event.get('action', '').lower()
    
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*', 
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'POST,OPTIONS' 
    }

    if action == 'read_names':
        print("Lambda Handler: Action 'read_names' requested.")
        response_body = {
            'message': 'List of target instance names collected from environment variables.',
            'target_instance_names': FOUND_TARGET_INSTANCE_NAMES
        }
        return {'statusCode': 200, 'headers': headers, 'body': json.dumps(response_body)}

    elif action in ['start', 'stop']:
        try:
            instance_name_tag_value = event['name']
        except KeyError:
            error_message = f"Parameter 'name' is missing in the event for action '{action}'."
            print(f"Lambda Handler: {error_message}")
            return {'statusCode': 400, 'headers': headers, 'body': json.dumps({'error': error_message})}

        if instance_name_tag_value not in FOUND_TARGET_INSTANCE_NAMES:
            print(f"Lambda Handler: Warning - Instance name '{instance_name_tag_value}' is not in the pre-defined list: {FOUND_TARGET_INSTANCE_NAMES}")
            # You might want to prevent action for non-listed names
            # error_message = f"Instance name '{instance_name_tag_value}' is not a configured target instance."
            # return {'statusCode': 403, 'headers': headers, 'body': json.dumps({'error': error_message})}


        instance_id = find_instance_id_by_tag_name(instance_name_tag_value)
        if not instance_id:
            message = f"No EC2 instance found with tag Name='{instance_name_tag_value}' for action '{action}'."
            print(f"Lambda Handler: {message}")
            return {'statusCode': 404, 'headers': headers, 'body': json.dumps({'message': message})}

        try:
            if action == 'start':
                print(f"Lambda Handler: Attempting to start instance: {instance_id} (Name: {instance_name_tag_value})")
                ec2_client.start_instances(InstanceIds=[instance_id])
                print(f"Lambda Handler: Start command sent for instance {instance_id}. Waiting for it to run...")
                
                waiter = ec2_client.get_waiter('instance_running')
                try:
                    waiter.wait(InstanceIds=[instance_id], WaiterConfig={'Delay': 15, 'MaxAttempts': 20})
                    print(f"Lambda Handler: Instance {instance_id} is now running.")
                    public_ip = get_instance_public_ip(instance_id)
                    message = f"Instance {instance_id} (Name: {instance_name_tag_value}) started successfully."
                    if public_ip:
                        message += f" Public IP: {public_ip}"
                    else:
                        message += " No public IP assigned or found."
                    
                    response_body = {'message': message, 'instance_id': instance_id, 'public_ip': public_ip}
                    return {'statusCode': 200, 'headers': headers, 'body': json.dumps(response_body)}

                except Exception as waiter_error: 
                    error_message = f"Error waiting for instance {instance_id} to start or instance did not start in time: {str(waiter_error)}"
                    print(f"Lambda Handler: {error_message}")
                    return {'statusCode': 500, 'headers': headers, 'body': json.dumps({'error': error_message, 'instance_id': instance_id})}

            elif action == 'stop':
                ssm_command_executed_successfully = None # To track SSM command status

                if instance_name_tag_value == "WPManagement":
                    print(f"Lambda Handler: Instance is '{instance_name_tag_value}'. Preparing to run SSM command to switch wp-config.php.")
                    
                    # Define the bash script for SSM Run Command
                    # This script will copy wp-config-production.php to wp-config.php
                    bash_script_commands = [
                        "#!/bin/bash",
                        "set -e", # Exit immediately if a command exits with a non-zero status.
                        "MOUNT_POINT='/var/www/html'",
                        "PRODUCTION_CONFIG_FILE=\"${MOUNT_POINT}/wp-config-production.php\"",
                        "ACTIVE_CONFIG_FILE=\"${MOUNT_POINT}/wp-config.php\"",
                        "APACHE_USER='apache'", # As per your setup script
                        "echo \"INFO: Starting wp-config switch script on $(hostname) at $(date)\"",
                        "if [ -f \"${PRODUCTION_CONFIG_FILE}\" ]; then",
                        "  echo \"INFO: Found ${PRODUCTION_CONFIG_FILE}. Attempting to copy to ${ACTIVE_CONFIG_FILE}...\"",
                        "  sudo cp -f \"${PRODUCTION_CONFIG_FILE}\" \"${ACTIVE_CONFIG_FILE}\"",
                        "  echo \"INFO: Copy complete. Setting ownership and permissions for ${ACTIVE_CONFIG_FILE}...\"",
                        "  sudo chown \"${APACHE_USER}:${APACHE_USER}\" \"${ACTIVE_CONFIG_FILE}\"",
                        "  sudo chmod 640 \"${ACTIVE_CONFIG_FILE}\"", # Consistent with your setup script's restricted permissions
                        "  echo \"INFO: Ownership and permissions set. ${ACTIVE_CONFIG_FILE} is now based on ${PRODUCTION_CONFIG_FILE}.\"",
                        "else",
                        "  echo \"ERROR: Production config file ${PRODUCTION_CONFIG_FILE} not found. No changes made to ${ACTIVE_CONFIG_FILE}.\"",
                        "  exit 1", # Critical error, SSM command should reflect failure
                        "fi",
                        "echo \"INFO: wp-config switch script finished successfully.\""
                    ]
                    
                    ssm_command_executed_successfully = execute_ssm_command_and_wait(
                        instance_id, 
                        bash_script_commands, 
                        instance_name_tag_value
                    )

                    if not ssm_command_executed_successfully:
                        # Log the failure but proceed to stop the instance
                        # You could choose to return an error here and not stop if the SSM command is critical
                        print(f"Lambda Handler: Warning - SSM command to switch wp-config.php for {instance_name_tag_value} ({instance_id}) failed or timed out. Proceeding with stop.")
                    else:
                        print(f"Lambda Handler: SSM command to switch wp-config.php for {instance_name_tag_value} ({instance_id}) succeeded.")

                # Proceed to stop the instance regardless of SSM command outcome for "WPManagement",
                # or if it's not "WPManagement"
                print(f"Lambda Handler: Attempting to stop instance: {instance_id} (Name: {instance_name_tag_value})")
                ec2_client.stop_instances(InstanceIds=[instance_id])
                
                base_message = f"Stop command sent for instance {instance_id} (Name: {instance_name_tag_value}). The instance is stopping."
                if instance_name_tag_value == "WPManagement":
                    if ssm_command_executed_successfully is True:
                        base_message += " wp-config.php was successfully switched to production version."
                    elif ssm_command_executed_successfully is False: # Explicitly check for False
                         base_message += " Attempt to switch wp-config.php to production version FAILED."
                    # If None, it means SSM wasn't attempted (e.g. wrong instance name, but this path is for "WPManagement")
                
                print(f"Lambda Handler: {base_message}")
                response_body = {'message': base_message, 'instance_id': instance_id}
                return {'statusCode': 200, 'headers': headers, 'body': json.dumps(response_body)}

        except Exception as e:
            error_message = f"Error executing action '{action}' on instance {instance_id} (Name: {instance_name_tag_value}): {str(e)}"
            print(f"Lambda Handler: {error_message}")
            return {'statusCode': 500, 'headers': headers, 'body': json.dumps({'error': error_message, 'instance_id': instance_id if 'instance_id' in locals() else 'N/A'})}
    else: 
        if not action:
            error_message = "Parameter 'action' is missing. Allowed actions: 'read_names', 'start', 'stop'."
        else:
            error_message = f"Invalid action: '{action}'. Allowed actions: 'read_names', 'start', or 'stop'."
        print(f"Lambda Handler: {error_message}")
        return {'statusCode': 400, 'headers': headers, 'body': json.dumps({'error': error_message})}