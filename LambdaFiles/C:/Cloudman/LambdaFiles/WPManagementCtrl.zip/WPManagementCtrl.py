import boto3
import json
import os
import time

# --- Global Scope: Initialization Code ---
ec2_client = boto3.client('ec2')
ssm_client = boto3.client('ssm')  # Initialize SSM client

FOUND_TARGET_INSTANCE_NAMES = []
print("Lambda Global: Starting initialization of instance name list from environment variables...")
ENV_VAR_BASE_NAME = "AWS_INSTANCE_TARGET_NAME_"
for i in range(10):
    env_var_key = f"{ENV_VAR_BASE_NAME}{i}"
    instance_name_from_env = os.environ.get(env_var_key)
    if instance_name_from_env:
        print(
            f"Lambda Global: Found environment variable '{env_var_key}' with value: '{instance_name_from_env}'")
        FOUND_TARGET_INSTANCE_NAMES.append(instance_name_from_env)
    else:
        print(
            f"Lambda Global: Environment variable '{env_var_key}' not set or is empty. Skipping.")
print(
    f"Lambda Global: Initialization complete. Collected target instance names: {FOUND_TARGET_INSTANCE_NAMES}")
# --- End of Global Scope Initialization ---


def find_instance_id_by_tag_name(name_tag_value):
    print(
        f"Function find_instance_id_by_tag_name: Searching for instance with tag Name='{name_tag_value}'")
    try:
        response = ec2_client.describe_instances(
            Filters=[
                {'Name': 'tag:Name', 'Values': [name_tag_value]},
                {'Name': 'instance-state-name',
                    'Values': ['pending', 'running', 'shutting-down', 'stopped', 'stopping']}
            ]
        )
        instances_found_ids = []
        for reservation in response.get('Reservations', []):
            for instance in reservation.get('Instances', []):
                instances_found_ids.append(instance['InstanceId'])
        if not instances_found_ids:
            print(
                f"Function find_instance_id_by_tag_name: No instance found with tag Name='{name_tag_value}'")
            return None
        if len(instances_found_ids) > 1:
            print(
                f"Function find_instance_id_by_tag_name: Warning - Multiple instances ({len(instances_found_ids)}) found with tag Name='{name_tag_value}'. Using the first one: {instances_found_ids[0]}")
        print(
            f"Function find_instance_id_by_tag_name: Instance found: {instances_found_ids[0]}")
        return instances_found_ids[0]
    except Exception as e:
        print(
            f"Function find_instance_id_by_tag_name: Error describing instances: {str(e)}")
        raise


def get_instance_public_ip(instance_id):
    try:
        print(
            f"Function get_instance_public_ip: Describing instance {instance_id} to get Public IP.")
        response = ec2_client.describe_instances(InstanceIds=[instance_id])
        if not response.get('Reservations') or not response['Reservations'][0].get('Instances'):
            print(
                f"Function get_instance_public_ip: Instance {instance_id} not found in describe_instances response.")
            return None
        instance_details = response['Reservations'][0]['Instances'][0]
        public_ip = instance_details.get('PublicIpAddress')
        if public_ip:
            print(
                f"Function get_instance_public_ip: Instance {instance_id} has Public IP: {public_ip}")
        else:
            print(
                f"Function get_instance_public_ip: Instance {instance_id} does not have a Public IP assigned.")
        return public_ip
    except Exception as e:
        print(
            f"Function get_instance_public_ip: Error describing instance {instance_id} to get IP: {str(e)}")
        return None


def execute_ssm_command_and_wait(instance_id, commands_to_run, instance_name_tag_value):
    """
    Executes a shell script via SSM Run Command and waits for completion.
    Returns True if successful, False otherwise.
    """
    print(
        f"SSM Handler: Attempting to run command on {instance_id} (Name: {instance_name_tag_value})")
    try:
        response = ssm_client.send_command(
            InstanceIds=[instance_id],
            DocumentName='AWS-RunShellScript',
            Parameters={'commands': commands_to_run},
            TimeoutSeconds=600,
            Comment=f'Execute custom commands for {instance_name_tag_value}'
        )
        command_id = response['Command']['CommandId']
        print(
            f"SSM Handler: Command sent. Command ID: {command_id}. Waiting for completion...")

        for _ in range(40):
            time.sleep(15)
            try:
                result = ssm_client.get_command_invocation(
                    CommandId=command_id,
                    InstanceId=instance_id
                )
                status = result['Status']
                print(
                    f"SSM Handler: Command {command_id} on {instance_id} status: {status}")

                if status == 'Success':
                    print(
                        f"SSM Handler: Command {command_id} on {instance_id} (Name: {instance_name_tag_value}) completed successfully.")
                    print(
                        f"SSM Handler: Standard Output:\n{result.get('StandardOutputContent', 'N/A')}")
                    return True
                elif status in ['Failed', 'Cancelled', 'TimedOut', 'DeliveryTimedOut', 'ExecutionTimedOut']:
                    print(
                        f"SSM Handler: Command {command_id} on {instance_id} (Name: {instance_name_tag_value}) ended with status: {status}")
                    print(
                        f"SSM Handler: Standard Output:\n{result.get('StandardOutputContent', 'N/A')}")
                    print(
                        f"SSM Handler: Standard Error:\n{result.get('StandardErrorContent', 'N/A')}")
                    return False
            except Exception as poll_e:
                print(
                    f"SSM Handler: Error polling command status for {command_id} on {instance_id}: {str(poll_e)}")
                return False

        print(
            f"SSM Handler: Command {command_id} on {instance_id} (Name: {instance_name_tag_value}) did not complete in the expected time (Lambda polling).")
        return False

    except Exception as e:
        print(
            f"SSM Handler: Error sending command to instance {instance_id} (Name: {instance_name_tag_value}): {str(e)}")
        return False


def lambda_handler(event, context):
    print(f"Lambda Handler: Event received: {json.dumps(event)}")
    action = event.get('action', '').lower()

    # Para integração AWS não-proxy, os cabeçalhos e o código de status são configurados
    # na "Integration Response" do API Gateway. A Lambda retorna apenas o payload.
    # Exemplo: {'message': 'Sucesso'} ou {'error': 'Algo deu errado'}

    instance_name_tag_value = None
    instance_id = None

    if action == 'read_names':
        print("Lambda Handler: Action 'read_names' requested.")
        # API Gateway Integration Response deve ser configurado para:
        # Status: 200 OK
        # Headers: Content-Type: application/json, CORS headers
        # Body: (o retorno desta função)
        return {
            'message': 'List of target instance names collected from environment variables.',
            'target_instance_names': FOUND_TARGET_INSTANCE_NAMES
        }

    # Lógica comum para ações que requerem 'name'
    if action in ['start', 'stop', 's3offload']:
        try:
            instance_name_tag_value = event['name']
        except KeyError:
            error_message = f"Parameter 'name' is missing in the event for action '{action}'."
            print(f"Lambda Handler: {error_message}")
            # API Gateway Integration Response deve mapear este tipo de retorno
            # (ex: contendo a chave 'error') para um status HTTP 400.
            return {'error': error_message}

        if instance_name_tag_value not in FOUND_TARGET_INSTANCE_NAMES:
            print(
                f"Lambda Handler: Warning - Instance name '{instance_name_tag_value}' is not in the pre-defined list: {FOUND_TARGET_INSTANCE_NAMES}. Proceeding with caution.")
            # Considere se isso deve ser um erro (ex: status 403 via API Gateway).
            # Se sim: return {'error': f"Instance name '{instance_name_tag_value}' is not a configured target."}

        instance_id = find_instance_id_by_tag_name(instance_name_tag_value)
        if not instance_id:
            message = f"No EC2 instance found with tag Name='{instance_name_tag_value}' for action '{action}'."
            print(f"Lambda Handler: {message}")
            # API Gateway Integration Response deve mapear para status HTTP 404.
            return {'error': message, 'instance_name_tag_value': instance_name_tag_value}

    # --- Início dos blocos de ação específicos ---
    if action == 's3offload':
        print(f"Lambda Handler: Action 's3offload' requested for instance: {instance_name_tag_value} ({instance_id})")
        
        if "WPAdmin" not in instance_name_tag_value:
            message = f"S3 offload action is only permitted for instances with 'WPAdmin' in their name. Instance name: '{instance_name_tag_value}'."
            print(f"Lambda Handler: {message}")
            # API Gateway Integration Response deve mapear para status HTTP 403.
            return {'error': message, 'instance_id': instance_id}

        try:
            instance_status_response = ec2_client.describe_instance_status(InstanceIds=[instance_id], IncludeAllInstances=True)
            instance_state = 'unknown'
            if instance_status_response.get('InstanceStatuses') and instance_status_response['InstanceStatuses']:
                 instance_state = instance_status_response['InstanceStatuses'][0]['InstanceState']['Name']
            
            if instance_state != 'running':
                message = f"Instance {instance_id} (Name: {instance_name_tag_value}) is not running (state: {instance_state}). S3 offload requires a running instance."
                print(f"Lambda Handler: {message}")
                # API Gateway Integration Response deve mapear para status HTTP 409.
                return {'error': message, 'instance_id': instance_id, 'instance_state': instance_state}
        except Exception as e:
            error_message = f"Could not verify instance status for {instance_id} (Name: {instance_name_tag_value}): {str(e)}"
            print(f"Lambda Handler: {error_message}")
            # API Gateway Integration Response deve mapear para status HTTP 500.
            return {'error': error_message, 'instance_id': instance_id}

        log_file = "/tmp/s3_offload_sync.log"
        commands_to_run = [
            f'echo "S3 Offload Script Started at $(date)" > {log_file}',
            (
                f'sudo aws s3 sync /var/www/html/wp-content s3://s3-projeto1-wp-offload-v1/wp-content/ '
                f'--exclude "*.php" '
                f'--include "*.css" --include "*.js" '
                f'--include "*.jpg" --include "*.jpeg" --include "*.png" --include "*.gif" '
                f'--include "*.svg" --include "*.webp" --include "*.ico" '
                f'--include "*.woff" --include "*.woff2" --include "*.ttf" --include "*.eot" --include "*.otf" '
                f'--exact-timestamps --delete >> {log_file} 2>&1'
            ),
            f'echo "wp-content sync finished at $(date)" >> {log_file} 2>&1',
            (
                f'aws s3 sync /var/www/html/wp-includes s3://s3-projeto1-wp-offload-v1/wp-includes/ '
                f'--exclude "*.php" '
                f'--include "*.css" --include "*.js" --include "*.jpg" --include "*.jpeg" '
                f'--include "*.png" --include "*.gif" --include "*.svg" --include "*.webp" '
                f'--include "*.ico" --include "*.woff" --include "*.woff2" --include "*.ttf" '
                f'--include "*.eot" --include "*.otf" '
                f'--exact-timestamps --delete >> {log_file} 2>&1'
            ),
            f'echo "wp-includes sync finished at $(date)" >> {log_file} 2>&1',
            f'echo "S3 Offload Script Completed at $(date)" >> {log_file}'
        ]
        
        print(f"Lambda Handler: Preparing to execute S3 offload commands on {instance_id} (Name: {instance_name_tag_value})")
        
        ssm_success = execute_ssm_command_and_wait(instance_id, commands_to_run, instance_name_tag_value)
        
        if ssm_success:
            message = f"S3 offload commands successfully executed on instance {instance_id} (Name: {instance_name_tag_value}). Check instance log {log_file} for details."
            print(f"Lambda Handler: {message}")
            # API Gateway Integration Response deve mapear para status HTTP 200.
            return {'message': message, 'instance_id': instance_id}
        else:
            error_message = f"S3 offload commands failed or timed out on instance {instance_id} (Name: {instance_name_tag_value}). Check SSM console or instance log {log_file} for details."
            print(f"Lambda Handler: {error_message}")
            # API Gateway Integration Response deve mapear para status HTTP 500.
            return {'error': error_message, 'instance_id': instance_id}

    elif action == 'start':
        try:
            print(f"Lambda Handler: Attempting to start instance: {instance_id} (Name: {instance_name_tag_value})")
            ec2_client.start_instances(InstanceIds=[instance_id])
            print(f"Lambda Handler: Start command sent for instance {instance_id}. Waiting for it to run...")

            waiter = ec2_client.get_waiter('instance_running')
            try:
                waiter.wait(InstanceIds=[instance_id], WaiterConfig={'Delay': 15, 'MaxAttempts': 20})
                print(f"Lambda Handler: Instance {instance_id} is now running.")
                public_ip = get_instance_public_ip(instance_id)
                message = f"Instance {instance_id} (Name: {instance_name_tag_value}) started successfully."
                if public_ip:
                    message += f" Public IP: {public_ip}"
                else:
                    message += " No public IP assigned or found."
                
                # API Gateway Integration Response deve mapear para status HTTP 200.
                return {'message': message, 'instance_id': instance_id, 'public_ip': public_ip}

            except Exception as waiter_error:
                error_message = f"Error waiting for instance {instance_id} to start or instance did not start in time: {str(waiter_error)}"
                print(f"Lambda Handler: {error_message}")
                public_ip_after_timeout_attempt = get_instance_public_ip(instance_id)
                # API Gateway Integration Response deve mapear para status HTTP 500.
                return {'error': error_message, 'instance_id': instance_id, 'current_public_ip': public_ip_after_timeout_attempt}

        except Exception as e:
            error_message = f"Error executing action '{action}' on instance {instance_id} (Name: {instance_name_tag_value}): {str(e)}"
            print(f"Lambda Handler: {error_message}")
            # API Gateway Integration Response deve mapear para status HTTP 500.
            return {'error': error_message, 'instance_id': instance_id if instance_id else 'N/A'}
            
    elif action == 'stop':
        try:
            if "WPAdmin" in instance_name_tag_value: # type: ignore
                print(f"Lambda Handler: Instance is '{instance_name_tag_value}'. This is a WPAdmin instance being stopped.")
                # Comandos pré-parada podem ser adicionados aqui e executados via SSM se necessário.

            print(f"Lambda Handler: Attempting to stop instance: {instance_id} (Name: {instance_name_tag_value})")
            ec2_client.stop_instances(InstanceIds=[instance_id]) # type: ignore
            base_message = f"Stop command sent for instance {instance_id} (Name: {instance_name_tag_value}). The instance is stopping."
            
            # API Gateway Integration Response deve mapear para status HTTP 200 (ou 202 Accepted).
            return {'message': base_message, 'instance_id': instance_id}

        except Exception as e:
            error_message = f"Error executing action '{action}' on instance {instance_id} (Name: {instance_name_tag_value}): {str(e)}"
            print(f"Lambda Handler: {error_message}")
            # API Gateway Integration Response deve mapear para status HTTP 500.
            return {'error': error_message, 'instance_id': instance_id if instance_id else 'N/A'}
    else:
        # Se 'action' não for 'read_names' e não estiver em ['start', 'stop', 's3offload']
        if not action:
            error_message = "Parameter 'action' is missing. Allowed actions: 'read_names', 'start', 'stop', 's3offload'."
        else:
            error_message = f"Invalid action: '{action}'. Allowed actions: 'read_names', 'start', 'stop', 's3offload'."
        print(f"Lambda Handler: {error_message}")
        # API Gateway Integration Response deve mapear para status HTTP 400.
        return {'error': error_message}