import boto3
import json
import os

# --- Global Scope: Initialization Code ---
# This code runs once when a new Lambda execution environment is created (cold start).

# Initialize EC2 client. It will infer the region from the Lambda execution environment.
ec2_client = boto3.client('ec2')

# This list will store the names of instances found during initialization
# by reading specific environment variables.
# It persists across invocations within the same Lambda container.
FOUND_TARGET_INSTANCE_NAMES = []

print("Lambda Global: Starting initialization of instance name list from environment variables...")

# The base name for the environment variables
ENV_VAR_BASE_NAME = "AWS_INSTANCE_TARGET_NAME_"

for i in range(10):  # Iterate for suffixes 0 through 9
    # Construct the full environment variable name, e.g., AWS_INSTANCE_TARGET_NAME_0, AWS_INSTANCE_TARGET_NAME_1, etc.
    env_var_key = f"{ENV_VAR_BASE_NAME}{i}"
    
    # Get the value of the environment variable. This value is the EC2 instance's 'Name' tag.
    instance_name_from_env = os.environ.get(env_var_key)
    
    if instance_name_from_env:
        print(f"Lambda Global: Found environment variable '{env_var_key}' with value: '{instance_name_from_env}'")
        FOUND_TARGET_INSTANCE_NAMES.append(instance_name_from_env)
    else:
        # This is not an error, just means that specific numbered target isn't defined.
        print(f"Lambda Global: Environment variable '{env_var_key}' not set or is empty. Skipping.")

print(f"Lambda Global: Initialization complete. Collected target instance names: {FOUND_TARGET_INSTANCE_NAMES}")

# --- End of Global Scope Initialization ---


def find_instance_id_by_tag_name(name_tag_value):
    """
    Finds the ID of an EC2 instance based on the value of its 'Name' tag.
    Returns the ID of the first instance found or None.
    """
    print(f"Function find_instance_id_by_tag_name: Searching for instance with tag Name='{name_tag_value}'")
    try:
        response = ec2_client.describe_instances(
            Filters=[
                {
                    'Name': 'tag:Name',
                    'Values': [name_tag_value]
                },
                {
                    'Name': 'instance-state-name',
                    'Values': ['pending', 'running', 'shutting-down', 'stopped', 'stopping']
                }
            ]
        )

        instances_found_ids = []
        for reservation in response.get('Reservations', []):
            for instance in reservation.get('Instances', []):
                instances_found_ids.append(instance['InstanceId'])

        if not instances_found_ids:
            print(f"Function find_instance_id_by_tag_name: No instance found with tag Name='{name_tag_value}'")
            return None

        if len(instances_found_ids) > 1:
            print(
                f"Function find_instance_id_by_tag_name: Warning - Multiple instances ({len(instances_found_ids)}) found with tag Name='{name_tag_value}'. Using the first one: {instances_found_ids[0]}")

        print(f"Function find_instance_id_by_tag_name: Instance found: {instances_found_ids[0]}")
        return instances_found_ids[0] # Return the ID of the first instance

    except Exception as e:
        print(f"Function find_instance_id_by_tag_name: Error describing instances: {str(e)}")
        raise


def lambda_handler(event, context):
    """
    Main handler for the Lambda function.
    """
    print(f"Lambda Handler: Event received: {json.dumps(event)}")

    action = event.get('action', '').lower()

    # 1. Handle the 'read_names' action
    if action == 'read_names':
        print("Lambda Handler: Action 'read_names' requested.")
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'List of target instance names collected from environment variables.',
                'target_instance_names': FOUND_TARGET_INSTANCE_NAMES # Return the globally stored list
            })
        }

    # 2. Handle 'start' and 'stop' actions
    elif action in ['start', 'stop']:
        try:
            instance_name_tag_value = event['name'] # The 'Name' tag of the instance to act upon
        except KeyError:
            error_message = f"Parameter 'name' is missing in the event for action '{action}'. Expected event: {{'name': 'INSTANCE_NAME_TAG_VALUE', 'action': '{action}'}}"
            print(f"Lambda Handler: {error_message}")
            return {
                'statusCode': 400,
                'body': json.dumps({'error': error_message})
            }

        # Check if the requested instance name is one of the pre-defined target names (optional, but good for validation)
        if instance_name_tag_value not in FOUND_TARGET_INSTANCE_NAMES:
            # You can decide how to handle this: proceed anyway, or return an error.
            # For now, let's print a warning and proceed.
            print(f"Lambda Handler: Warning - Instance name '{instance_name_tag_value}' is not in the pre-defined list of target names: {FOUND_TARGET_INSTANCE_NAMES}")
            # If you want to restrict actions only to pre-defined names, uncomment the following:
            # error_message = f"Instance name '{instance_name_tag_value}' is not a configured target instance."
            # print(f"Lambda Handler: {error_message}")
            # return {
            #     'statusCode': 400, # Bad Request or 403 Forbidden
            #     'body': json.dumps({'error': error_message})
            # }


        instance_id = find_instance_id_by_tag_name(instance_name_tag_value)

        if not instance_id:
            message = f"No EC2 instance found with the tag Name='{instance_name_tag_value}' for action '{action}'."
            print(f"Lambda Handler: {message}")
            return {
                'statusCode': 404,  # Not Found
                'body': json.dumps({'message': message})
            }

        try:
            if action == 'start':
                print(f"Lambda Handler: Starting instance: {instance_id} (Name: {instance_name_tag_value})")
                response = ec2_client.start_instances(InstanceIds=[instance_id])
                print(f"Lambda Handler: Response from start_instances: {response}")
                message = f"Command to start instance {instance_id} (Name: {instance_name_tag_value}) sent successfully."

            elif action == 'stop':
                print(f"Lambda Handler: Stopping instance: {instance_id} (Name: {instance_name_tag_value})")
                response = ec2_client.stop_instances(InstanceIds=[instance_id])
                print(f"Lambda Handler: Response from stop_instances: {response}")
                message = f"Command to stop instance {instance_id} (Name: {instance_name_tag_value}) sent successfully."

            return {
                'statusCode': 200,
                'body': json.dumps({'message': message, 'instance_id': instance_id})
            }

        except Exception as e:
            error_message = f"Error executing action '{action}' on instance {instance_id} (Name: {instance_name_tag_value}): {str(e)}"
            print(f"Lambda Handler: {error_message}")
            return {
                'statusCode': 500,
                'body': json.dumps({'error': error_message, 'instance_id': instance_id})
            }

    # 3. Handle unknown or missing action
    else:
        if not action:
            error_message = "Parameter 'action' is missing in the event. Allowed actions: 'read_names', 'start', 'stop'."
        else:
            error_message = f"Invalid action: '{action}'. Allowed actions are 'read_names', 'start', or 'stop'."
        print(f"Lambda Handler: {error_message}")
        return {
            'statusCode': 400,
            'body': json.dumps({'error': error_message})
        }