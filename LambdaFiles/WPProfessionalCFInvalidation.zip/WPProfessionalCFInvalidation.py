import json
import os
import boto3
import time
import urllib.parse

# Inicializar o cliente do CloudFront fora do handler para reutilização em execuções "quentes"
cloudfront_client = boto3.client('cloudfront')


def lambda_handler(event, context):
    # 1. Obter o ID da Distribuição do CloudFront da variável de ambiente
    # O usuário mencionou "essa AWS CloudFront Distribution como nome" para a variável de ambiente
    cloudfront_distribution_id = os.environ.get(
        "AWS_CLOUDFRONT_DISTRIBUTION_TARGET_ID_0")

    if not cloudfront_distribution_id:
        print(
            f"Erro: A variável de ambiente 'AWS_CLOUDFRONT_DISTRIBUTION_TARGET_ID_0' não está configurada.")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': f"Erro de configuração: A variável de ambiente 'AWS_CLOUDFRONT_DISTRIBUTION_TARGET_ID_0' não está configurada."
            })
        }
    print(f"ID da Distribuição CloudFront: {cloudfront_distribution_id}")

    # 2. Extrair os caminhos dos arquivos do evento S3
    paths_to_invalidate = []
    if 'Records' not in event:
        print("Aviso: Nenhum 'Records' encontrado no evento. Isso pode ser um evento de teste ou gatilho não S3.")
    else:
        for record in event.get('Records', []):
            if 's3' in record and 'object' in record['s3'] and 'key' in record['s3']['object']:
                s3_object_key = record['s3']['object']['key']

                # Chaves de objeto S3 podem ter caracteres codificados por URL (ex: espaços como '+')
                # Caminhos do CloudFront precisam ser decodificados e começar com '/'
                decoded_key = urllib.parse.unquote_plus(s3_object_key)
                # Adiciona a barra inicial
                invalidation_path = f"/{decoded_key}"

                paths_to_invalidate.append(invalidation_path)
                print(
                    f"Adicionando à lista de invalidação: '{invalidation_path}' (originado de s3://{record['s3']['bucket']['name']}/{s3_object_key})")
            else:
                print(
                    f"Aviso: Registro não contém informações S3 esperadas: {json.dumps(record)}")

    if not paths_to_invalidate:
        print("Nenhum caminho para invalidar foi derivado do evento S3.")
        return {
            'statusCode': 200,  # Pode ser 400 se um evento S3 era esperado mas não produziu caminhos
            'body': json.dumps({'message': 'Nenhum caminho para invalidar derivado do evento.'})
        }

    # 3. Criar a invalidação no CloudFront
    # Usar um timestamp como CallerReference para garantir que seja único
    caller_reference = str(time.time())

    try:
        print(
            f"Criando invalidação para os caminhos: {paths_to_invalidate} na distribuição {cloudfront_distribution_id}")
        response = cloudfront_client.create_invalidation(
            DistributionId=cloudfront_distribution_id,
            InvalidationBatch={
                'Paths': {
                    'Quantity': len(paths_to_invalidate),
                    'Items': paths_to_invalidate
                },
                'CallerReference': caller_reference
            }
        )
        invalidation_id = response['Invalidation']['Id']
        print(
            f"Solicitação de invalidação do CloudFront enviada com sucesso. ID da Invalidação: {invalidation_id}")
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Solicitação de invalidação do CloudFront enviada com sucesso.',
                'invalidationId': invalidation_id,
                'pathsInvalidated': paths_to_invalidate
            })
        }
    except Exception as e:
        print(f"Erro ao criar a invalidação no CloudFront: {str(e)}")
        # Logar o traceback completo para depuração em CloudWatch Logs
        import traceback
        traceback.print_exc()
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Falha ao criar a invalidação no CloudFront.',
                'error': str(e)
            })
        }
