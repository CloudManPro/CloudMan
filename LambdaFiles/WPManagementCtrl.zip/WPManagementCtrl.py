import boto3
import json
import os
import time

# --- Global Scope: Initialization Code ---
ec2_client = boto3.client('ec2')
ssm_client = boto3.client('ssm')

FOUND_TARGET_INSTANCE_NAMES = []
print("Lambda Global: Starting initialization of instance name list from environment variables...")
ENV_VAR_BASE_NAME = "AWS_INSTANCE_TARGET_NAME_"
for i in range(10):
    env_var_key = f"{ENV_VAR_BASE_NAME}{i}"
    instance_name_from_env = os.environ.get(env_var_key)
    if instance_name_from_env:
        print(
            f"Lambda Global: Found environment variable '{env_var_key}' with value: '{instance_name_from_env}'")
        FOUND_TARGET_INSTANCE_NAMES.append(instance_name_from_env)
    else:
        # This log can be noisy if few vars are set, consider reducing verbosity if not needed
        # print(
        #     f"Lambda Global: Environment variable '{env_var_key}' not set or is empty. Skipping.")
        pass
print(
    f"Lambda Global: Initialization complete. Collected target instance names: {FOUND_TARGET_INSTANCE_NAMES}")
# --- End of Global Scope Initialization ---


def find_instance_id_by_tag_name(name_tag_value):
    print(
        f"Function find_instance_id_by_tag_name: Searching for instance with tag Name='{name_tag_value}'")
    try:
        response = ec2_client.describe_instances(
            Filters=[
                {'Name': 'tag:Name', 'Values': [name_tag_value]},
                {'Name': 'instance-state-name',
                    'Values': ['pending', 'running', 'shutting-down', 'stopped', 'stopping']}
            ]
        )
        instances_found_ids = []
        for reservation in response.get('Reservations', []):
            for instance in reservation.get('Instances', []):
                instances_found_ids.append(instance['InstanceId'])
        if not instances_found_ids:
            print(
                f"Function find_instance_id_by_tag_name: No instance found (or not in allowed states) with tag Name='{name_tag_value}'")
            return None
        if len(instances_found_ids) > 1:
            print(
                f"Function find_instance_id_by_tag_name: Warning - Multiple instances ({len(instances_found_ids)}) found with tag Name='{name_tag_value}'. Using the first one: {instances_found_ids[0]}")
        print(
            f"Function find_instance_id_by_tag_name: Instance found: {instances_found_ids[0]} for tag Name='{name_tag_value}'")
        return instances_found_ids[0]
    except Exception as e:
        print(
            f"Function find_instance_id_by_tag_name: Error describing instances for tag Name='{name_tag_value}': {str(e)}")
        raise # Re-raise to be caught by handler if critical


def get_instance_public_ip(instance_id):
    try:
        print(
            f"Function get_instance_public_ip: Describing instance {instance_id} to get Public IP.")
        response = ec2_client.describe_instances(InstanceIds=[instance_id])
        if not response.get('Reservations') or not response['Reservations'][0].get('Instances'):
            print(
                f"Function get_instance_public_ip: Instance {instance_id} not found in describe_instances response.")
            return None
        instance_details = response['Reservations'][0]['Instances'][0]
        public_ip = instance_details.get('PublicIpAddress')
        if public_ip:
            print(
                f"Function get_instance_public_ip: Instance {instance_id} has Public IP: {public_ip}")
        else:
            print(
                f"Function get_instance_public_ip: Instance {instance_id} does not have a Public IP assigned.")
        return public_ip
    except Exception as e:
        print(
            f"Function get_instance_public_ip: Error describing instance {instance_id} to get IP: {str(e)}")
        return None


def get_instance_state_by_id(instance_id, name_for_log="N/A"):
    """
    Gets the state of a given instance ID.
    Returns the state string (e.g., 'running', 'stopped') or a specific status string on failure.
    """
    try:
        print(f"Function get_instance_state_by_id: Describing instance status for {instance_id} (Name Log: {name_for_log}).")
        response = ec2_client.describe_instance_status(
            InstanceIds=[instance_id],
            IncludeAllInstances=True 
        )
        if response.get('InstanceStatuses') and response['InstanceStatuses']:
            state = response['InstanceStatuses'][0]['InstanceState']['Name']
            print(f"Function get_instance_state_by_id: Instance {instance_id} (Name Log: {name_for_log}) state via describe_instance_status: {state}")
            return state
        else:
            print(f"Function get_instance_state_by_id: No status found for {instance_id} (Name Log: {name_for_log}) via describe_instance_status. Attempting fallback with describe_instances.")
            try:
                desc_inst_response = ec2_client.describe_instances(InstanceIds=[instance_id])
                if desc_inst_response.get('Reservations') and desc_inst_response['Reservations'][0].get('Instances'):
                    state = desc_inst_response['Reservations'][0]['Instances'][0]['State']['Name']
                    print(f"Function get_instance_state_by_id (fallback describe_instances): Instance {instance_id} state: {state}")
                    return state
                else: 
                    print(f"Function get_instance_state_by_id (fallback describe_instances): Instance {instance_id} not found by describe_instances either.")
                    return 'not_found_definitive' 
            except ec2_client.exceptions.ClientError as e_desc:
                if e_desc.response['Error']['Code'] == 'InvalidInstanceID.NotFound':
                    print(f"Function get_instance_state_by_id (fallback describe_instances): Instance {instance_id} InvalidInstanceID.NotFound.")
                    return 'not_found_definitive'
                print(f"Function get_instance_state_by_id: ClientError during fallback describe_instances for {instance_id}: {str(e_desc)}")
                return 'error_getting_state'
            except Exception as e_gen_desc:
                print(f"Function get_instance_state_by_id: Generic error during fallback describe_instances for {instance_id}: {str(e_gen_desc)}")
                return 'error_getting_state'

    except ec2_client.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'InvalidInstanceID.NotFound':
            print(f"Function get_instance_state_by_id: Instance {instance_id} (Name Log: {name_for_log}) primary check InvalidInstanceID.NotFound.")
            return 'not_found_definitive' 
        print(f"Function get_instance_state_by_id: ClientError for instance {instance_id} (Name Log: {name_for_log}): {str(e)}")
        return 'error_getting_state'
    except Exception as e:
        print(f"Function get_instance_state_by_id: Generic error for instance {instance_id} (Name Log: {name_for_log}): {str(e)}")
        return 'error_getting_state'


def execute_ssm_command_and_wait(instance_id, commands_to_run, instance_name_tag_value):
    print(
        f"SSM Handler: Attempting to run command on {instance_id} (Name: {instance_name_tag_value})")
    try:
        response = ssm_client.send_command(
            InstanceIds=[instance_id],
            DocumentName='AWS-RunShellScript',
            Parameters={'commands': commands_to_run},
            TimeoutSeconds=600, # Consider if this timeout is sufficient for all commands
            Comment=f'Execute custom commands for {instance_name_tag_value}'
        )
        command_id = response['Command']['CommandId']
        print(
            f"SSM Handler: Command sent. Command ID: {command_id}. Waiting for completion...")

        # Max wait time: 40 * 15s = 600s = 10 minutes.
        # Lambda timeout should be configured higher than this if this is blocking.
        for i in range(40): 
            time.sleep(15) 
            try:
                result = ssm_client.get_command_invocation(
                    CommandId=command_id,
                    InstanceId=instance_id
                )
                status = result['Status']
                print(
                    f"SSM Handler: Poll {i+1}/40. Command {command_id} on {instance_id} status: {status}")

                if status == 'Success':
                    print(
                        f"SSM Handler: Command {command_id} on {instance_id} (Name: {instance_name_tag_value}) completed successfully.")
                    print(
                        f"SSM Handler: Standard Output:\n{result.get('StandardOutputContent', 'N/A')}")
                    return True
                elif status in ['Failed', 'Cancelled', 'TimedOut', 'DeliveryTimedOut', 'ExecutionTimedOut']:
                    print(
                        f"SSM Handler: Command {command_id} on {instance_id} (Name: {instance_name_tag_value}) ended with status: {status}")
                    print(
                        f"SSM Handler: Standard Output:\n{result.get('StandardOutputContent', 'N/A')}")
                    print(
                        f"SSM Handler: Standard Error:\n{result.get('StandardErrorContent', 'N/A')}")
                    return False
            except Exception as poll_e:
                print(
                    f"SSM Handler: Error polling command status for {command_id} on {instance_id}: {str(poll_e)}. Assuming failure for this poll cycle.")
                # Depending on the error, you might not want to immediately return False.
                # If it's a transient network issue polling, retrying might be an option.
                # For simplicity here, we'll let it loop or if it's a critical polling error, it might return False.
                if i == 39: # If it's the last attempt and polling failed
                    return False


        print(
            f"SSM Handler: Command {command_id} on {instance_id} (Name: {instance_name_tag_value}) did not complete in the Lambda polling time (40 retries). Status was {status if 'status' in locals() else 'Unknown'}.")
        return False

    except Exception as e:
        print(
            f"SSM Handler: Error sending command to instance {instance_id} (Name: {instance_name_tag_value}): {str(e)}")
        return False


def lambda_handler(event, context):
    print(f"Lambda Handler: Event received: {json.dumps(event)}")
    action = event.get('action', '').lower()

    if action == 'read_names':
        print(f"Lambda Handler: Action 'read_names' requested. Returning: {FOUND_TARGET_INSTANCE_NAMES}")
        return {
            'message': 'List of target instance names collected from environment variables.',
            'target_instance_names': FOUND_TARGET_INSTANCE_NAMES
        }
    
    elif action == 'status':
        print("Lambda Handler: Action 'status' requested.")
        instance_statuses_list = []
        if not FOUND_TARGET_INSTANCE_NAMES:
            print("Lambda Handler: No target instances configured in FOUND_TARGET_INSTANCE_NAMES for status check.")
            return {
                'message': 'No target instances configured to get status for.',
                'statuses': []
            }

        print(f"Lambda Handler: Processing statuses for names: {FOUND_TARGET_INSTANCE_NAMES}")
        for name_tag_value_for_status in FOUND_TARGET_INSTANCE_NAMES:
            instance_id_for_status = find_instance_id_by_tag_name(name_tag_value_for_status)
            current_status_val = 'not_found_by_tag' 
            
            if instance_id_for_status:
                state_from_ec2 = get_instance_state_by_id(instance_id_for_status, name_tag_value_for_status)
                current_status_val = state_from_ec2 # This will be the actual state or an error/not_found string
            
            instance_statuses_list.append({
                'name': name_tag_value_for_status,
                'id': instance_id_for_status, 
                'status': current_status_val
            })
        
        print(f"Lambda Handler: Statuses collected: {instance_statuses_list}")
        return {
            'message': 'Instance statuses retrieved successfully.',
            'statuses': instance_statuses_list
        }

    # --- Actions below require 'name' in event payload ---
    instance_name_tag_value = event.get('name')
    
    if not instance_name_tag_value:
        if action in ['start', 'stop', 's3offload']:
            message = f"Parameter 'name' (instance name tag) is missing for action '{action}'."
            print(f"Lambda Handler: {message}")
            return {'error': message} 
    
    instance_id = None
    if instance_name_tag_value: 
        try:
            instance_id = find_instance_id_by_tag_name(instance_name_tag_value)
        except Exception as find_id_err: # Catch errors from find_instance_id_by_tag_name
            message = f"Error finding instance ID for Name='{instance_name_tag_value}': {str(find_id_err)}"
            print(f"Lambda Handler: {message}")
            return {'error': message, 'instance_name_tag_value': instance_name_tag_value}

        if not instance_id and action in ['start', 'stop', 's3offload']:
            message = f"No EC2 instance found (or not in allowed state) with tag Name='{instance_name_tag_value}' for action '{action}'."
            print(f"Lambda Handler: {message}")
            return {'error': message, 'instance_name_tag_value': instance_name_tag_value}
    
    # --- Action-specific logic using instance_id and instance_name_tag_value ---
    if action == 's3offload':
        if not instance_id or not instance_name_tag_value:
             return {'error': f"Instance details missing for S3 offload. Name: '{instance_name_tag_value}', ID: '{instance_id}'."}

        print(f"Lambda Handler: Action 's3offload' requested for instance: {instance_name_tag_value} ({instance_id})")
        
        instance_state = get_instance_state_by_id(instance_id, instance_name_tag_value)

        if instance_state in ['error_getting_state', 'not_found_definitive', None]:
            error_message = f"Could not reliably determine instance status for {instance_id} (Name: {instance_name_tag_value}). Reported state: {instance_state}"
            print(f"Lambda Handler: {error_message}")
            return {'error': error_message, 'instance_id': instance_id, 'instance_state_debug': instance_state}

        if instance_state != 'running':
            message = f"Instance {instance_id} (Name: {instance_name_tag_value}) is not running (state: {instance_state}). S3 offload requires a running instance."
            print(f"Lambda Handler: {message}")
            return {'error': message, 'instance_id': instance_id, 'instance_state': instance_state}
        
        command_event_payload = event.get('command')
        if not command_event_payload:
            return {'error': "Parameter 'command' is missing for s3offload action."}

        commands_to_run = []
        log_file = "/tmp/s3_offload_general.log" # Default log file

        if command_event_payload == 'offload_wp-content':
            log_file = "/tmp/s3_offload_wp_content.log"
            commands_to_run = [
                f'echo "S3 Offload wp-content Script Started at $(date)" > {log_file}',
                (
                    f'sudo aws s3 sync /var/www/html/wp-content s3://s3-projeto1-wp-offload-v1/wp-content/ '
                    f'--exclude "*.php" --exclude "uploads/*" ' # Keep uploads out of this generic sync
                    f'--include "*.css" --include "*.js" '
                    f'--include "*.jpg" --include "*.jpeg" --include "*.png" --include "*.gif" '
                    f'--include "*.svg" --include "*.webp" --include "*.ico" '
                    f'--include "*.woff" --include "*.woff2" --include "*.ttf" --include "*.eot" --include "*.otf" '
                    f'--exact-timestamps --delete --size-only >> {log_file} 2>&1' # Added --size-only
                ),
                f'echo "wp-content sync finished at $(date)" >> {log_file} 2>&1',
            ]
        elif command_event_payload == 'offload_wp-includes':
            log_file = "/tmp/s3_offload_wp_includes.log"
            commands_to_run = [
                f'echo "S3 Offload wp-includes Script Started at $(date)" > {log_file}',
                (
                    f'sudo aws s3 sync /var/www/html/wp-includes s3://s3-projeto1-wp-offload-v1/wp-includes/ '
                    f'--exclude "*.php" '
                    f'--include "*.css" --include "*.js" --include "*.jpg" --include "*.jpeg" '
                    f'--include "*.png" --include "*.gif" --include "*.svg" --include "*.webp" '
                    f'--include "*.ico" --include "*.woff" --include "*.woff2" --include "*.ttf" '
                    f'--include "*.eot" --include "*.otf" '
                    f'--exact-timestamps --delete --size-only >> {log_file} 2>&1' # Added --size-only
                ),
                f'echo "wp-includes sync finished at $(date)" >> {log_file} 2>&1',
            ]
        elif command_event_payload == 'offload_deletex':
            log_file = "/var/log/meus_scripts/local_file_deletion.log" # Make sure this path is writable by SSM agent user
            extensions_to_delete = [
                "*.css", "*.js",
                "*.jpg", "*.jpeg", "*.png", "*.gif",
                "*.svg", "*.webp", "*.ico",
                "*.woff", "*.woff2", "*.ttf", "*.eot", "*.otf"
            ]
            find_name_conditions_str = " -o ".join([f"-name '{ext}'" for ext in extensions_to_delete])
            # Ensure log directory exists
            log_dir = os.path.dirname(log_file)
            commands_to_run = [
                f'sudo mkdir -p {log_dir} && sudo touch {log_file} && sudo chmod 666 {log_file}', # Ensure log file is accessible
                f'echo "Local File Deletion Script Started at $(date)" > {log_file}',
                (
                    f'echo "Finding and deleting files in /var/www/html/wp-content and /var/www/html/wp-includes..." >> {log_file} 2>&1 && '
                    f'sudo find /var/www/html/wp-content -type f ' 
                    f'\\( {find_name_conditions_str} \\) '          
                    f'! -path "*/uploads/*" ' # Exclude uploads directory entirely
                    f'! -name "*.php" '                           
                    f'-print -delete '                            
                    f'>> {log_file} 2>&1 || '                     
                    f'echo "Warning or error during find and delete operation. Check details." >> {log_file} 2>&1'
                ),
                f'echo "Local file deletion finished at $(date)" >> {log_file} 2>&1',
            ]
        else:
            return {'error': f"Invalid command '{command_event_payload}' for s3offload action."}

        print(f"Lambda Handler: Preparing to execute S3 offload command '{command_event_payload}' on {instance_id} (Name: {instance_name_tag_value})")
        ssm_success = execute_ssm_command_and_wait(instance_id, commands_to_run, instance_name_tag_value)

        if ssm_success:
            message = f"S3 offload command '{command_event_payload}' successfully executed on instance {instance_name_tag_value}. Check instance log {log_file} for details."
            print(f"Lambda Handler: {message}")
            return {'message': message, 'instance_id': instance_id}
        else:
            error_message = f"S3 offload command '{command_event_payload}' failed or timed out on instance {instance_name_tag_value}. Check SSM console or instance log {log_file} for details."
            print(f"Lambda Handler: {error_message}")
            return {'error': error_message, 'instance_id': instance_id}

    elif action == 'start':
        if not instance_id or not instance_name_tag_value: return {'error': f"Instance details missing for start action. Name: '{instance_name_tag_value}', ID: '{instance_id}'."}
        try:
            print(f"Lambda Handler: Attempting to start instance: {instance_id} (Name: {instance_name_tag_value})")
            ec2_client.start_instances(InstanceIds=[instance_id])
            print(f"Lambda Handler: Start command sent for instance {instance_id}. Waiting for it to run...")

            waiter = ec2_client.get_waiter('instance_running')
            try:
                waiter.wait(InstanceIds=[instance_id], WaiterConfig={'Delay': 15, 'MaxAttempts': 20}) # Max 5 mins wait
                print(f"Lambda Handler: Instance {instance_id} is now running.")
                public_ip = get_instance_public_ip(instance_id)
                message = f"Instance {instance_name_tag_value} (ID: {instance_id}) started successfully."
                if public_ip:
                    message += f" Public IP: {public_ip}"
                else:
                    message += " No public IP assigned or found."
                return {'message': message, 'instance_id': instance_id, 'public_ip': public_ip}

            except Exception as waiter_error:
                error_message = f"Instance {instance_name_tag_value} (ID: {instance_id}) did not start or waiter timed out: {str(waiter_error)}"
                print(f"Lambda Handler: {error_message}")
                public_ip_after_timeout_attempt = get_instance_public_ip(instance_id)
                current_state_after_timeout = get_instance_state_by_id(instance_id, instance_name_tag_value)
                return {'error': error_message, 'instance_id': instance_id, 
                        'current_public_ip': public_ip_after_timeout_attempt,
                        'current_state': current_state_after_timeout}

        except Exception as e:
            error_message = f"Error executing action '{action}' on instance {instance_name_tag_value} (ID: {instance_id}): {str(e)}"
            print(f"Lambda Handler: {error_message}")
            return {'error': error_message, 'instance_id': instance_id if instance_id else 'N/A'}
            
    elif action == 'stop':
        if not instance_id or not instance_name_tag_value: return {'error': f"Instance details missing for stop action. Name: '{instance_name_tag_value}', ID: '{instance_id}'."}
        try:
            if "WPAdmin" in instance_name_tag_value:
                print(f"Lambda Handler: Instance is '{instance_name_tag_value}'. This is a WPAdmin instance being stopped.")

            print(f"Lambda Handler: Attempting to stop instance: {instance_id} (Name: {instance_name_tag_value})")
            ec2_client.stop_instances(InstanceIds=[instance_id])
            base_message = f"Stop command sent for instance {instance_name_tag_value} (ID: {instance_id}). The instance is stopping."
            return {'message': base_message, 'instance_id': instance_id}

        except Exception as e:
            error_message = f"Error executing action '{action}' on instance {instance_name_tag_value} (ID: {instance_id}): {str(e)}"
            print(f"Lambda Handler: {error_message}")
            return {'error': error_message, 'instance_id': instance_id if instance_id else 'N/A'}
    else:
        if not action:
            error_message = "Parameter 'action' is missing."
        else:
            error_message = f"Invalid action: '{action}'. Allowed: 'read_names', 'status', 'start', 'stop', 's3offload'."
        print(f"Lambda Handler: {error_message}")
        return {'error': error_message}