import boto3
import os
import json


def lambda_handler(event, context):

    # Identifique a fonte do evento
    source = event.get('source')
    print(f"Fonte do evento: {source}")

    # Executa a lógica de limpeza do DynamoDB
    table_name = os.getenv("AWS_DYNAMODB_TABLE_TARGET_NAME_0")
    region_name = os.getenv("AWS_DYNAMODB_TABLE_TARGET_REGION_0")

    if not table_name or not region_name:
        raise ValueError(
            "Variáveis de ambiente AWS_DYNAMODB_TABLE_TARGET_NAME_0 ou AWS_DYNAMODB_TABLE_TARGET_REGION_0 não definidas."
        )

    print(f"Tabela DynamoDB: {table_name}")
    print(f"Região DynamoDB: {region_name}")

    # Inicializa cliente DynamoDB
    dynamodb = boto3.client('dynamodb', region_name=region_name)

    # Extrair o BuildID completo do evento recebido
    full_build_id = event['detail']['build-id']
    print(f"BuildID completo recebido: {full_build_id}")

    # Extrai valor após "/"
    build_id = full_build_id.split("/")[-1]
    print(f"BuildID final extraído: {build_id}")

    # Consulta para validar itens na tabela
    print("Consulta toda Tabela: Validando itens...")
    full_query = dynamodb.scan(TableName=table_name)

    # Verifique LockID diretamente na tabela
    matched_item = None
    for item in full_query['Items']:
        lock_id = item['LockID']['S']
        if build_id in lock_id:
            matched_item = item
            break  # Parar quando encontrar

    if not matched_item:
        print(f"Erro: LockID ou BuildId = {build_id} sem resultados")
        return {
            'statusCode': 404,
            'body': json.dumps({"message": "LockID relacionado não encontrado"})
        }

    lock_id = matched_item['LockID']['S']
    print(f"Correspondência encontrada com LockID: {lock_id}")

    # Deletar lock associado
    delete_response = dynamodb.delete_item(
        TableName=table_name,
        Key={'LockID': {'S': lock_id}}
    )

    print(
        f"Item deletado com sucesso: {json.dumps(delete_response, indent=2)}")
    return {
        'statusCode': 200,
        'body': json.dumps({"mensagem": "Sucesso!", 'deleted_lock_id': lock_id})
    }
