import boto3
import os
import json
import urllib.request
import urllib.error
from datetime import datetime, timezone

# --- Variáveis de Ambiente Esperadas ---
# REGION: Região da AWS (ex: 'us-east-1')
# AWS_CODEPIPELINE_TARGET_NAME_0: Nome do CodePipeline a ser monitorado
# AWS_S3_BUCKET_TARGET_NAME_0: Nome do bucket S3 para salvar o relatório
# AWS_SSM_PARAMETER_SOURCE_ARN_0: Nome do parâmetro no SSM Parameter Store (ex: /meu/app/dominio)

def get_pipeline_status(codepipeline_client, pipeline_name):
    """
    Busca o estado da última execução de um CodePipeline.
    """
    try:
        pipeline_state = codepipeline_client.get_pipeline_state(name=pipeline_name)
        return pipeline_state
    except Exception as e:
        print(f"Erro ao buscar estado do CodePipeline: {e}")
        raise

def format_pipeline_report(state):
    """
    Formata os dados brutos do pipeline em um relatório de texto legível.
    """
    report_lines = []

    # --- Cabeçalho do Relatório ---
    report_lines.append("="*60)
    report_lines.append("        Relatório de Execução do AWS CodePipeline")
    report_lines.append("="*60)
    report_lines.append("")

    # --- Informações Gerais do Pipeline ---
    pipeline_name = state.get('pipelineName', 'N/A')
    pipeline_version = state.get('pipelineVersion', 'N/A')
    
    # Encontra o status geral na última etapa executada
    overall_status = "N/A"
    if state.get('stageStates'):
        last_stage = state['stageStates'][-1]
        if last_stage.get('latestExecution'):
            overall_status = last_stage['latestExecution'].get('status', 'N/A')

    report_lines.append(f"Pipeline: {pipeline_name} (Versão: {pipeline_version})")
    report_lines.append(f"Status Geral: {overall_status}")

    # --- Duração Total ---
    created_time = state.get('created')
    updated_time = state.get('updated')
    if created_time and updated_time:
        # Garante que os datetimes estão cientes do fuso horário para o cálculo
        duration = updated_time - created_time
        total_seconds = duration.total_seconds()
        minutes, seconds = divmod(total_seconds, 60)
        report_lines.append(f"Início da Execução: {created_time.astimezone(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} (UTC)")
        report_lines.append(f"Última Atualização: {updated_time.astimezone(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} (UTC)")
        report_lines.append(f"Duração Total: {int(minutes)} minutos e {int(seconds)} segundos")
    
    report_lines.append("")

    # --- Detalhes dos Estágios e Ações ---
    for stage in state.get('stageStates', []):
        stage_name = stage.get('stageName', 'Estágio Desconhecido')
        report_lines.append("-" * 60)
        report_lines.append(f"▶ Estágio: {stage_name}")
        report_lines.append("-" * 60)

        for action in stage.get('actionStates', []):
            action_name = action.get('actionName', 'Ação Desconhecida')
            report_lines.append(f"  - Ação: {action_name}")
            
            latest_exec = action.get('latestExecution')
            if latest_exec:
                status = latest_exec.get('status', 'N/A')
                summary = latest_exec.get('summary', 'Sem sumário.')
                last_change = latest_exec.get('lastStatusChange')
                exec_url = latest_exec.get('externalExecutionUrl')

                report_lines.append(f"    - Status: {status}")
                report_lines.append(f"    - Sumário: {summary}")
                if last_change:
                    report_lines.append(f"    - Horário: {last_change.astimezone(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} (UTC)")
                if exec_url:
                    report_lines.append(f"    - Link para Detalhes: {exec_url}")
            else:
                # Caso a ação não tenha sido executada ainda ou os dados não estejam disponíveis
                report_lines.append("    - Status: Informação não disponível nesta execução.")
            
            report_lines.append("") # Linha em branco para separar ações

    return "\n".join(report_lines)


def get_url_from_ssm(ssm_client, parameter_name):
    """Busca o domínio de um parâmetro JSON no SSM."""
    try:
        response = ssm_client.get_parameter(Name=parameter_name, WithDecryption=True)
        parameter_value_str = response['Parameter']['Value']
        resources_data = json.loads(parameter_value_str)
        
        for resource in resources_data:
            if resource.get("ResourceType") == "aws_route53_zone":
                domain = resource.get("Domain")
                if domain: return domain
        
        raise ValueError("Recurso 'aws_route53_zone' com 'Domain' não encontrado no SSM.")
    except Exception as e:
        print(f"Erro ao buscar parâmetro do SSM: {e}")
        raise

def fetch_url_content(url):
    """Acessa uma URL e retorna seu conteúdo ou uma mensagem de erro."""
    full_url = f"https://{url}"
    print(f"Acessando a URL: {full_url}")
    try:
        with urllib.request.urlopen(full_url, timeout=10) as response:
            return response.read().decode('utf-8')
    except Exception as e:
        error_message = f"Falha ao acessar a URL {full_url}. Erro: {str(e)}"
        print(error_message)
        return error_message

def upload_to_s3(s3_client, bucket_name, file_name, content_string):
    """Salva um conteúdo de texto em um bucket S3."""
    try:
        s3_client.put_object(
            Bucket=bucket_name,
            Key=file_name,
            Body=content_string,
            ContentType='text/plain; charset=utf-8' # Alterado para texto plano
        )
        print(f"Relatório '{file_name}' salvo com sucesso no bucket '{bucket_name}'.")
    except Exception as e:
        print(f"Erro ao salvar no S3: {e}")
        raise

def lambda_handler(event, context):
    try:
        # 1. Obter variáveis de ambiente
        region = os.environ['REGION']
        pipeline_name = os.environ['AWS_CODEPIPELINE_TARGET_NAME_0']
        s3_bucket_name = os.environ['AWS_S3_BUCKET_TARGET_NAME_0']
        ssm_parameter_name = os.environ['AWS_SSM_PARAMETER_SOURCE_ARN_0']
        
        # 2. Inicializar clientes Boto3
        codepipeline_client = boto3.client('codepipeline', region_name=region)
        ssm_client = boto3.client('ssm', region_name=region)
        s3_client = boto3.client('s3', region_name=region)

        # 3. Coletar dados do Pipeline
        print("--- Coletando dados do Pipeline ---")
        pipeline_data = get_pipeline_status(codepipeline_client, pipeline_name)
        
        # 4. Formatar o relatório do pipeline para texto
        formatted_pipeline_report = format_pipeline_report(pipeline_data)
        
        # 5. Coletar dados da aplicação (URL e conteúdo)
        print("--- Coletando dados da aplicação web ---")
        web_server_domain = get_url_from_ssm(ssm_client, ssm_parameter_name)
        web_page_content = fetch_url_content(web_server_domain)
        
        # 6. Montar o relatório final combinando as duas partes
        final_report_parts = [formatted_pipeline_report]
        final_report_parts.append("\n" + "="*60)
        final_report_parts.append("        Status da Aplicação em Produção")
        final_report_parts.append("="*60 + "\n")
        
        page_status = "Acesso com sucesso." if "<html>" in web_page_content.lower() else "Conteúdo inesperado ou erro."
        
        final_report_parts.append(f"URL Acessada: https://{web_server_domain}")
        final_report_parts.append(f"Status: {page_status}")
        final_report_parts.append("Conteúdo da Página (Prévia):")
        final_report_parts.append(web_page_content[:1000] + ('...' if len(web_page_content) > 1000 else ''))
        
        final_report_string = "\n".join(final_report_parts)
        
        # 7. Salvar o relatório de texto no S3
        timestamp_str = datetime.now(timezone.utc).strftime('%Y-%m-%d_%H-%M-%S')
        file_name = f"deploy-report-{timestamp_str}.txt" # Alterado para .txt
        
        upload_to_s3(s3_client, s3_bucket_name, file_name, final_report_string)

        return {
            'statusCode': 200,
            'body': json.dumps(f"Relatório '{file_name}' gerado e salvo com sucesso em '{s3_bucket_name}'.")
        }

    except KeyError as e:
        error_msg = f"Erro: Variável de ambiente obrigatória não definida: {e}"
        print(error_msg)
        return {'statusCode': 500, 'body': json.dumps(error_msg)}
    except Exception as e:
        error_msg = f"Ocorreu um erro inesperado: {str(e)}"
        print(error_msg)
        return {'statusCode': 500, 'body': json.dumps(error_msg)}