import json
import boto3
import csv
import io
from decimal import Decimal, ROUND_HALF_UP

# --- Constantes ---
# Altere para o nome da sua tag se for diferente (case-sensitive)
RESOURCE_TAG_KEY = 'resourceTags/user:Name'
COST_COLUMN = 'lineItem/UnblendedCost'
PRODUCT_COLUMN = 'lineItem/ProductCode'
USAGE_TYPE_COLUMN = 'lineItem/UsageType'
OPERATION_COLUMN = 'lineItem/Operation'

# Helper function para converter Decimal para string para JSON


def decimal_default(obj):
    if isinstance(obj, Decimal):
        # Formata para 8 casas decimais como no CUR, arredondando
        return str(obj.quantize(Decimal('0.00000001'), rounding=ROUND_HALF_UP))
    raise TypeError


def initialize_resource_structure():
    """Cria a estrutura de dicionário padrão para um novo recurso."""
    return {
        "StorageCost": Decimal('0.0'),
        "RequestCosts": {},
        "OtherCosts": {},
        "TotalUnblendedCost": Decimal('0.0')
    }


def lambda_handler(event, context):
    """
    Processa um arquivo CUR do S3 para agregar custos por tag 'Name'.
    """
    print(f"Received event: {json.dumps(event)}")

    # 1. Obter informações do arquivo S3 do evento
    try:
        # Assumindo um trigger S3 padrão
        s3_event = event['Records'][0]['s3']
        bucket_name = s3_event['bucket']['name']
        object_key = s3_event['object']['key']
    except (KeyError, IndexError) as e:
        print(f"Error extracting S3 info from event: {e}")
        return {'statusCode': 400, 'body': 'Invalid S3 event structure'}

    print(f"Processing file: s3://{bucket_name}/{object_key}")

    # 2. Acessar e ler o arquivo CUR do S3
    s3_client = boto3.client('s3')
    aggregated_costs = {}

    try:
        s3_object = s3_client.get_object(Bucket=bucket_name, Key=object_key)
        body = s3_object['Body']
        csv_content = body.read().decode('utf-8')
        csv_reader = csv.DictReader(io.StringIO(csv_content))

        print("Successfully read S3 object. Processing rows...")
        processed_rows = 0
        tagged_items_found = 0

        # 3. Processar cada linha do CSV
        for row_num, row in enumerate(csv_reader):
            processed_rows += 1
            tag_value = row.get(RESOURCE_TAG_KEY)

            # Pular linhas sem a tag de interesse
            if not tag_value:
                continue

            tagged_items_found += 1

            # Inicializar estrutura se a tag for nova
            if tag_value not in aggregated_costs:
                aggregated_costs[tag_value] = initialize_resource_structure()

            # Obter informações da linha
            product_code = row.get(PRODUCT_COLUMN, '')
            usage_type = row.get(USAGE_TYPE_COLUMN, '')
            # Default se vazio
            operation = row.get(OPERATION_COLUMN, 'UnknownOperation')
            cost_str = row.get(COST_COLUMN)

            # Converter custo para Decimal
            try:
                cost = Decimal(cost_str) if cost_str else Decimal('0.0')
            except Exception as e:  # Captura InvalidOperation de Decimal ou outros erros
                print(
                    f"Warning: Could not parse cost '{cost_str}' in row {row_num+1}. Skipping cost addition for this row. Error: {e}")
                cost = Decimal('0.0')

            # Atualizar custo total sempre
            aggregated_costs[tag_value]['TotalUnblendedCost'] += cost

            # 4. Categorizar e agregar custos (Foco S3 + Fallback)
            if product_code == 'AmazonS3':
                if 'TimedStorage-ByteHrs' in usage_type:
                    aggregated_costs[tag_value]['StorageCost'] += cost
                elif 'Requests-Tier' in usage_type:
                    if operation not in aggregated_costs[tag_value]['RequestCosts']:
                        aggregated_costs[tag_value]['RequestCosts'][operation] = Decimal(
                            '0.0')
                    aggregated_costs[tag_value]['RequestCosts'][operation] += cost
                elif 'Bucket-Hrs' in usage_type:
                    other_key = 'BucketHourCost'
                    if other_key not in aggregated_costs[tag_value]['OtherCosts']:
                        aggregated_costs[tag_value]['OtherCosts'][other_key] = Decimal(
                            '0.0')
                    aggregated_costs[tag_value]['OtherCosts'][other_key] += cost
                elif 'TagStorage' in usage_type:
                    other_key = 'TagStorageCost'
                    if other_key not in aggregated_costs[tag_value]['OtherCosts']:
                        aggregated_costs[tag_value]['OtherCosts'][other_key] = Decimal(
                            '0.0')
                    aggregated_costs[tag_value]['OtherCosts'][other_key] += cost
                else:
                    # Outros custos S3 específicos
                    other_key = f"S3:{usage_type}"
                    if other_key not in aggregated_costs[tag_value]['OtherCosts']:
                        aggregated_costs[tag_value]['OtherCosts'][other_key] = Decimal(
                            '0.0')
                    aggregated_costs[tag_value]['OtherCosts'][other_key] += cost

            elif product_code == 'AmazonDynamoDB':
                if 'TimedStorage-ByteHrs' in usage_type:
                    aggregated_costs[tag_value]['StorageCost'] += cost
                elif 'CapacityUnit-Hrs' in usage_type or 'Requests' in usage_type:
                    other_key = f"DynamoDB:{usage_type}"
                    if other_key not in aggregated_costs[tag_value]['OtherCosts']:
                        aggregated_costs[tag_value]['OtherCosts'][other_key] = Decimal(
                            '0.0')
                    aggregated_costs[tag_value]['OtherCosts'][other_key] += cost
                else:
                    # Fallback genérico para DynamoDB
                    other_key = f"DynamoDB:Other:{usage_type}"
                    if other_key not in aggregated_costs[tag_value]['OtherCosts']:
                        aggregated_costs[tag_value]['OtherCosts'][other_key] = Decimal(
                            '0.0')
                    aggregated_costs[tag_value]['OtherCosts'][other_key] += cost

            elif product_code == 'AWSLambda':
                if 'GB-Second' in usage_type:
                    other_key = "Lambda:DurationCost"
                    if other_key not in aggregated_costs[tag_value]['OtherCosts']:
                        aggregated_costs[tag_value]['OtherCosts'][other_key] = Decimal(
                            '0.0')
                    aggregated_costs[tag_value]['OtherCosts'][other_key] += cost
                elif 'Request' in usage_type:
                    other_key = "Lambda:RequestCost"
                    if other_key not in aggregated_costs[tag_value]['OtherCosts']:
                        aggregated_costs[tag_value]['OtherCosts'][other_key] = Decimal(
                            '0.0')
                    aggregated_costs[tag_value]['OtherCosts'][other_key] += cost
                else:
                    # Fallback genérico para Lambda
                    other_key = f"Lambda:Other:{usage_type}"
                    if other_key not in aggregated_costs[tag_value]['OtherCosts']:
                        aggregated_costs[tag_value]['OtherCosts'][other_key] = Decimal(
                            '0.0')
                    aggregated_costs[tag_value]['OtherCosts'][other_key] += cost

            elif product_code == 'CodeBuild':
                if 'Build-Sec' in usage_type:
                    other_key = "CodeBuild:BuildSecondsCost"
                    if other_key not in aggregated_costs[tag_value]['OtherCosts']:
                        aggregated_costs[tag_value]['OtherCosts'][other_key] = Decimal(
                            '0.0')
                    aggregated_costs[tag_value]['OtherCosts'][other_key] += cost
                else:
                    # Fallback genérico para CodeBuild
                    other_key = f"CodeBuild:Other:{usage_type}"
                    if other_key not in aggregated_costs[tag_value]['OtherCosts']:
                        aggregated_costs[tag_value]['OtherCosts'][other_key] = Decimal(
                            '0.0')
                    aggregated_costs[tag_value]['OtherCosts'][other_key] += cost

            else:
                # Fallback genérico para outros produtos
                other_key = f"{product_code}:{usage_type}"
                if other_key not in aggregated_costs[tag_value]['OtherCosts']:
                    aggregated_costs[tag_value]['OtherCosts'][other_key] = Decimal(
                        '0.0')
                aggregated_costs[tag_value]['OtherCosts'][other_key] += cost

        print(f"Processed {processed_rows} rows.")
        print(
            f"Found {tagged_items_found} items with tag '{RESOURCE_TAG_KEY}'.")

        # 5. Converter Decimals para strings antes de serializar para JSON
        final_output = json.loads(json.dumps(
            aggregated_costs, default=decimal_default))

        print("Final aggregated costs:")
        print(json.dumps(final_output, indent=2))

        return {
            'statusCode': 200,
            'body': json.dumps(final_output)
        }

    except s3_client.exceptions.NoSuchKey:
        print(f"Error: Object not found - s3://{bucket_name}/{object_key}")
        return {'statusCode': 404, 'body': 'CUR file not found'}
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        # Adicione mais logging ou tratamento de erro específico se necessário
        raise e  # Relança a exceção para marcar a execução do Lambda como falha
