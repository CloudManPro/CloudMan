import os
import json
import boto3
import pymysql
# import logging # Removido
# from phpserialize import loads as php_loads # Removido

# --- Configuração do Logger (Substituído por print) ---
# logger = logging.getLogger()
# logger.setLevel(logging.INFO)


def log_print(level, message):
    print(f"[{level.upper()}] {message}")


# --- Variáveis de Configuração (Lidas do Ambiente) ---
SECRET_NAME = os.environ.get('AWS_SECRETSMANAGER_SECRET_VERSION_SOURCE_NAME_0')
SECRET_REGION = os.environ.get(
    'AWS_SECRETSMANAGER_SECRET_VERSION_SOURCE_REGION_0')

# S3 - Variáveis lidas, mas não usadas ativamente nesta versão
S3_BUCKET_NAME = os.environ.get('AWS_S3_BUCKET_TARGET_NAME_0')
S3_BUCKET_REGION = os.environ.get('AWS_S3_BUCKET_TARGET_REGION_0')
S3_UPLOADS_BASE_PATH = os.environ.get(
    'S3_UPLOADS_BASE_PATH', 'wp-content/uploads/')

# RDS
DB_HOST = os.environ.get('AWS_DB_INSTANCE_TARGET_ENDPOINT_0')
DB_NAME = os.environ.get('AWS_DB_INSTANCE_TARGET_NAME_0')
DB_REGION = os.environ.get('AWS_DB_INSTANCE_TARGET_REGION_0')

# --- Constantes ---
QUEUE_TABLE_NAME = 'wp_s3_deletion_queue'
MAX_RETRIES = 3
BATCH_SIZE = 10

# --- Clientes AWS ---
secrets_manager_client = None
# s3_client = None # Removido nesta versão


def init_clients():
    global secrets_manager_client
    if secrets_manager_client is None:
        secrets_manager_client = boto3.client(
            'secretsmanager', region_name=SECRET_REGION)
    # S3 client não é inicializado nesta versão


def get_db_credentials():
    log_print(
        "info", f"Tentando obter segredo: {SECRET_NAME} da região {SECRET_REGION}")
    try:
        response = secrets_manager_client.get_secret_value(
            SecretId=SECRET_NAME)
        if 'SecretString' in response:
            secret = json.loads(response['SecretString'])
            db_user = secret.get('username')
            db_password = secret.get('password')

            if not db_user or not db_password:
                raise ValueError("Segredo não contém 'username' ou 'password'")
            log_print(
                "info", "Credenciais do DB obtidas com sucesso do Secrets Manager.")
            return db_user, db_password
        else:
            raise ValueError(
                "SecretString não encontrado na resposta do Secrets Manager")
    except Exception as e:
        log_print(
            "error", f"Erro ao obter credenciais do Secrets Manager: {e}")
        raise


def connect_to_db(db_user, db_password):
    log_print("info", f"Conectando ao DB: Host={DB_HOST}, DBName={DB_NAME}")
    try:
        conn = pymysql.connect(
            host=DB_HOST,
            user=db_user,
            password=db_password,
            database=DB_NAME,
            connect_timeout=10,
            cursorclass=pymysql.cursors.DictCursor
        )
        log_print("info", "Conexão com o DB estabelecida.")
        return conn
    except pymysql.MySQLError as e:
        log_print("error", f"Erro ao conectar ao banco de dados: {e}")
        raise


def ensure_queue_table_exists(cursor):
    create_table_sql = f"""
    CREATE TABLE IF NOT EXISTS {QUEUE_TABLE_NAME} (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        post_id_deleted BIGINT UNSIGNED NULL,
        attachment_metadata_snapshot LONGTEXT NULL,
        status ENUM('PENDING', 'PROCESSING', 'DONE', 'ERROR') NOT NULL DEFAULT 'PENDING',
        event_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        processed_timestamp TIMESTAMP NULL,
        error_message TEXT NULL,
        retry_count INT DEFAULT 0,
        INDEX idx_status_timestamp (status, event_timestamp)
    );
    """
    try:
        log_print("info", f"Verificando/Criando tabela: {QUEUE_TABLE_NAME}")
        cursor.execute(create_table_sql)
        log_print("info", f"Tabela {QUEUE_TABLE_NAME} verificada/criada.")
    except pymysql.MySQLError as e:
        log_print(
            "error", f"Erro ao criar/verificar tabela {QUEUE_TABLE_NAME}: {e}")
        raise


def process_queue_items(conn, cursor):
    log_print(
        "info", "Iniciando processamento de itens da fila (versão simplificada).")

    select_sql = f"""
    SELECT id, post_id_deleted, attachment_metadata_snapshot
    FROM {QUEUE_TABLE_NAME}
    WHERE (status = 'PENDING' OR (status = 'ERROR' AND retry_count < %s))
    ORDER BY event_timestamp ASC
    LIMIT %s;
    """
    try:
        cursor.execute(select_sql, (MAX_RETRIES, BATCH_SIZE))
        items = cursor.fetchall()
    except pymysql.MySQLError as e:
        log_print("error", f"Erro ao selecionar itens da fila: {e}")
        return

    if not items:
        log_print("info", "Nenhum item para processar na fila.")
        return

    log_print("info", f"Encontrados {len(items)} itens para processar.")

    for item in items:
        item_id = item['id']
        log_print("info", f"Processando item ID: {item_id}")

        update_status_sql = f"UPDATE {QUEUE_TABLE_NAME} SET status = 'PROCESSING', processed_timestamp = NOW() WHERE id = %s"
        try:
            cursor.execute(update_status_sql, (item_id,))
            conn.commit()
        except pymysql.MySQLError as e:
            log_print(
                "error", f"Item ID {item_id}: Erro ao atualizar status para PROCESSING: {e}")
            conn.rollback()
            continue

        final_status = 'DONE'  # Por padrão, assume sucesso na versão simplificada
        error_occurred = False
        current_error_message = None

        try:
            # Mostra uma parte
            log_print(
                "info", f"Item ID {item_id}: attachment_metadata_snapshot: {item.get('attachment_metadata_snapshot')[:200]}...")
            log_print(
                "info", f"Item ID {item_id}: Lógica de parse PHP e deleção S3 DESABILITADA para este teste.")
            # Nenhuma ação de parse ou S3 aqui

        except Exception as e_proc:
            log_print(
                "error", f"Item ID {item_id}: Erro inesperado durante o processamento simplificado: {e_proc}")
            error_occurred = True
            current_error_message = str(e_proc)
            final_status = 'ERROR'

        if error_occurred:
            update_final_sql = f"""
            UPDATE {QUEUE_TABLE_NAME}
            SET status = %s, processed_timestamp = NOW(), error_message = %s, retry_count = retry_count + 1
            WHERE id = %s;
            """
            params = (
                final_status, current_error_message[:65535] if current_error_message else None, item_id)
        else:
            update_final_sql = f"""
            UPDATE {QUEUE_TABLE_NAME}
            SET status = %s, processed_timestamp = NOW(), error_message = NULL
            WHERE id = %s;
            """
            params = (final_status, item_id)

        try:
            cursor.execute(update_final_sql, params)
            conn.commit()
            log_print(
                "info", f"Item ID {item_id}: Status final atualizado para {final_status}.")
        except pymysql.MySQLError as e_update_final:
            log_print(
                "error", f"Item ID {item_id}: Erro CRÍTICO ao atualizar status final para {final_status}: {e_update_final}")
            conn.rollback()

    log_print(
        "info", "Processamento da fila (simplificado) concluído para este lote.")


def lambda_handler(event, context):
    log_print(
        "info", f"Lambda invocada (versão simplificada). Evento: {event}")

    required_env_vars = [
        SECRET_NAME, SECRET_REGION,
        DB_HOST, DB_NAME
        # S3_BUCKET_NAME e S3_UPLOADS_BASE_PATH não são críticos para esta versão, mas mantidos na verificação
    ]
    # Adicionando explicitamente os nomes das variáveis para a mensagem de erro
    env_var_map = {
        'AWS_SECRETSMANAGER_SECRET_VERSION_SOURCE_NAME_0': SECRET_NAME,
        'AWS_SECRETSMANAGER_SECRET_VERSION_SOURCE_REGION_0': SECRET_REGION,
        'AWS_S3_BUCKET_TARGET_NAME_0': S3_BUCKET_NAME,  # Mantido para consistência
        'S3_UPLOADS_BASE_PATH': S3_UPLOADS_BASE_PATH,     # Mantido para consistência
        'AWS_DB_INSTANCE_TARGET_ENDPOINT_0': DB_HOST,
        'AWS_DB_INSTANCE_TARGET_NAME_0': DB_NAME
    }

    missing = [name for name, value in env_var_map.items() if not value]
    if missing:
        log_print(
            "error", f"Variáveis de ambiente obrigatórias ausentes: {missing}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': f"Variáveis de ambiente obrigatórias ausentes: {missing}"})
        }

    init_clients()
    conn = None
    try:
        db_user, db_password = get_db_credentials()
        conn = connect_to_db(db_user, db_password)

        with conn.cursor() as cursor:
            ensure_queue_table_exists(cursor)
            conn.commit()

            process_queue_items(conn, cursor)

        log_print(
            "info", "Execução da Lambda (simplificada) concluída com sucesso.")
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Processamento da fila (simplificado) concluído.'})
        }

    except Exception as e:
        log_print(
            "error", f"Erro geral na execução da Lambda (simplificada): {e}")
        if conn:
            try:
                conn.rollback()
            except Exception as rb_e:
                log_print("error", f"Erro ao tentar rollback: {rb_e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': f"Erro na execução da Lambda (simplificada): {str(e)}"})
        }
    finally:
        if conn:
            try:
                conn.close()
                log_print("info", "Conexão com o DB fechada.")
            except Exception as close_e:
                log_print("error", f"Erro ao fechar conexão com DB: {close_e}")
