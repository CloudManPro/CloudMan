# file: my_math_functions.py

def multiply(a, b):
    return a * b